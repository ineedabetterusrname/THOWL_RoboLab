# ============================================================
# ROBOTIC BRICKLAYING - running-bond wall assembly
# ------------------------------------------------------------
# The classic AEC robotics demo (Gramazio Kohler's "programmed
# wall"): the robot picks bricks from a supply station with an
# OnRobot 2FG7 parallel gripper and lays a small wall in running
# bond, course by course. The wall geometry is *computed*, not
# taught - change the parameters and the same code builds a
# different wall.
#
# Runs unchanged on the lab UR10e and in the web simulator
# (teach pendant -> Code tab):
#   https://ineedabetterusrname.github.io/ur10e-simulator/
# In the simulator, also add "Bricks (graspable)" from the
# catalogue: the first brick appears at the pick station, and
# you can drag bricks back onto it between cycles to keep the
# supply stocked.
#
# Prerequisite (real robot): pip install ur_rtde
# ============================================================
import rtde_control
import rtde_receive

try:
    from onrobot import TwoFG7            # provided by the web simulator
except ImportError:                        # real robot: OnRobot Compute Box
    import xmlrpc.client
    class TwoFG7:
        """Minimal 2FG7 wrapper. Check the method names against your
        OnRobot Compute Box XML-RPC documentation before first use."""
        def __init__(self, ip, port=41414):
            self._cb = xmlrpc.client.ServerProxy("http://%s:%d" % (ip, port))
        def grip(self, width_mm, force=80, speed=100, wait=True):
            self._cb.twofg_grip_external(0, float(width_mm), force, speed)
        def open(self, width_mm=73.0):
            self.grip(width_mm, force=20)
        def get_width(self):
            return self._cb.twofg_get_external_width(0)

ROBOT_IP = "YOUR_ROBOT_IP"     # ignored by the simulator

# ---- wall parameters (metres / millimetres) ----------------
BRICK_L = 0.120                # brick length (along the wall)
BRICK_W = 60.0                 # brick width the gripper grabs [mm]
BRICK_H = 0.062                # course height (brick + tolerance)
COURSES = 3                    # number of courses (rows)
BRICKS_PER_COURSE = 3
JOINT_GAP = 0.012              # head-joint gap between bricks

# ---- stations (robot base frame) ---------------------------
PICK = (0.69, -0.32)           # brick supply point [m]
WALL_X, WALL_Y0 = 0.69, 0.02   # wall start; wall runs along +Y
Z_TRAVEL = 0.28                # carry height [m]
Z_GRIP = 0.032                 # grip-point height at floor level [m]

def goto(rtde_c, pose, x, y, z, v=0.25):
    p = list(pose)
    p[0], p[1], p[2] = x, y, z
    rtde_c.moveL(p, speed=v)

def main():
    rtde_c = rtde_control.RTDEControlInterface(ROBOT_IP)
    rtde_r = rtde_receive.RTDEReceiveInterface(ROBOT_IP)
    gripper = TwoFG7(ROBOT_IP)

    work = [0.0, -1.31, -1.75, -1.66, 1.57, 0.0]   # tool points straight down
    rtde_c.moveJ(work, speed=1.0)
    pose = rtde_r.getActualTCPPose()               # keep this orientation
    gripper.open(73)

    total = 0
    for course in range(COURSES):
        # running bond: every second course shifts by half a brick
        offset = (BRICK_L + JOINT_GAP) / 2 if course % 2 else 0.0
        z_place = Z_GRIP + course * BRICK_H
        print(f"course {course + 1}/{COURSES}")
        for i in range(BRICKS_PER_COURSE):
            y = WALL_Y0 + offset + i * (BRICK_L + JOINT_GAP)
            # pick a brick from the supply station
            goto(rtde_c, pose, PICK[0], PICK[1], Z_TRAVEL)
            goto(rtde_c, pose, PICK[0], PICK[1], Z_GRIP, v=0.1)
            gripper.grip(BRICK_W - 5)              # fingers stop on the brick
            goto(rtde_c, pose, PICK[0], PICK[1], Z_TRAVEL)
            # place it in the wall
            goto(rtde_c, pose, WALL_X, y, Z_TRAVEL)
            goto(rtde_c, pose, WALL_X, y, z_place + 0.004, v=0.1)
            gripper.open(73)                       # release - brick settles
            goto(rtde_c, pose, WALL_X, y, Z_TRAVEL)
            total += 1
            print(f"  brick {total}: course {course + 1}, bay {i + 1}")

    rtde_c.moveJ(work, speed=1.0)
    print(f"wall complete: {total} bricks, {COURSES} courses")
    rtde_c.disconnect()

if __name__ == "__main__":
    main()
