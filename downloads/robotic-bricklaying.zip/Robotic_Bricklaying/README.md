# Robotic Bricklaying — running-bond wall

Single-file demo of computed masonry: the robot picks bricks from a supply
point with the lab's **OnRobot 2FG7 parallel gripper** and lays a small wall
in **running bond**, course by course. The wall is generated from parameters
(brick size, courses, joint gap) — edit them and the same script builds a
different wall. This is the canonical architecture-robotics exercise
(compare Gramazio Kohler's *programmed wall*).

## Run it

**Simulator first** (no hardware needed): open the
[web simulator](https://ineedabetterusrname.github.io/ur10e-simulator/) →
teach pendant → **Code** tab → paste `robotic_bricklaying.py` → **Run**.
The 2FG7 mounts automatically; add **Bricks (graspable)** from the catalogue
and the first brick appears at the pick station. Bricks are physical: the
fingers stop on contact, the brick rides the TCP, and releasing drops it
onto the floor or the course below. Drag a brick back onto the pick station
between cycles to restock the supply.

**Real robot:** `pip install ur_rtde`, set `ROBOT_IP`, pendant in
*Remote Control*, speed slider low. The gripper falls back to a small
OnRobot Compute Box XML-RPC wrapper — verify the RPC method names against
your OnRobot software version.

## Ideas to extend

- Read brick positions from a Grasshopper-exported JSON instead of a grid
- Add a mortar/adhesive dispensing pass between courses
- Detect a missing brick at the pick station from the gripper width after
  closing (`get_width()` ≈ minimum → nothing was grabbed)
